"""Figure 2, Panels a–c — PDF of collective polarization M.

Produces three PDF files:
  figure_2_panel_a.pdf  —  Spain confined arena   (%RT = 100, 50, 25, 0, LD, All)
  figure_2_panel_b.pdf  —  Spain open schoolyard  (%RT = 50, 25, 0, All)
  figure_2_panel_c.pdf  —  Japan confined arena   (%RT = 50, 25, 0, All)
"""

import os
import numpy as np
import openpyxl
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from scipy.ndimage import uniform_filter1d

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE  = os.path.join(SCRIPT_DIR, "..", "SourceData.xlsx")

wb   = openpyxl.load_workbook(DATA_FILE, read_only=True)
ws   = wb["Figure 2"]
rows = list(ws.iter_rows(values_only=True))
wb.close()

def col_values(col_idx, skip=4):
    return np.array([float(r[col_idx]) for r in rows[skip:] if r[col_idx] is not None])

# Panel a — Spain confined (cols 1–5)
pa_100 = col_values(1);  pa_50 = col_values(2)
pa_25  = col_values(3);  pa_0  = col_values(4)
pa_LD  = col_values(5)
pa_all = np.concatenate([pa_100, pa_50, pa_25, pa_0, pa_LD])

# Panel b — Spain open schoolyard (cols 8–10)
pb_50  = col_values(8);  pb_25 = col_values(9)
pb_0   = col_values(10)
pb_all = np.concatenate([pb_50, pb_25, pb_0])

# Panel c — Japan confined (cols 13–15)
pc_50  = col_values(13); pc_25 = col_values(14)
pc_0   = col_values(15)
pc_all = np.concatenate([pc_50, pc_25, pc_0])

N_BINS   = 15
BIN_LIM  = (-1.0, 1.0)
SMOOTH_W = 5

def smooth_pdf(data):
    counts, edges = np.histogram(data, bins=N_BINS, range=BIN_LIM, density=True)
    centers = edges[:-1] + (edges[1] - edges[0]) / 2
    f       = interp1d(centers, counts, kind="cubic", fill_value="extrapolate")
    x_fine  = np.linspace(centers[0], centers[-1], len(centers) * 2 - 1)
    return x_fine, uniform_filter1d(f(x_fine), size=SMOOTH_W)

C100 = "#EA5D47"; C50 = "#9E0142"; C25 = "#3D5A80"
C0   = "#56A110"; CLD = "#FDBF6F"; CALL = "black"
LW_COND = 3.0;    LW_ALL  = 4.0

def format_ax(ax, label):
    ax.axvline(0, color="black", linewidth=2.0, linestyle="--")
    ax.set_xlim(-1, 1)
    ax.set_ylim(-0.05, 3.0)
    ax.set_xlabel(r"$M$", fontsize=16)
    ax.set_ylabel("pdf",  fontsize=16)
    ax.tick_params(which="both", direction="in", length=7, width=1.5, labelsize=16)
    ax.tick_params(which="minor", length=4)
    ax.xaxis.set_minor_locator(plt.MultipleLocator(0.1))
    ax.yaxis.set_minor_locator(plt.MultipleLocator(0.25))
    for sp in ax.spines.values():
        sp.set_linewidth(1.5)
    ax.text(0.04, 0.96, label, transform=ax.transAxes,
            fontsize=16, fontweight="bold", va="top")

PANELS = [
    {
        "label":      "a",
        "out":        os.path.join(SCRIPT_DIR, "figure_2_panel_a.pdf"),
        "conditions": [
            (pa_100, C100,  LW_COND, "100%"),
            (pa_50,  C50,   LW_COND, "50%"),
            (pa_25,  C25,   LW_COND, "25%"),
            (pa_0,   C0,    LW_COND, "0%"),
            (pa_LD,  CLD,   LW_COND, "LD"),
            (pa_all, CALL,  LW_ALL,  "All"),
        ],
        "legend": True,
    },
    {
        "label":      "b",
        "out":        os.path.join(SCRIPT_DIR, "figure_2_panel_b.pdf"),
        "conditions": [
            (pb_50,  C50,  LW_COND, "50%"),
            (pb_25,  C25,  LW_COND, "25%"),
            (pb_0,   C0,   LW_COND, "0%"),
            (pb_all, CALL, LW_ALL,  "All"),
        ],
        "legend": False,
    },
    {
        "label":      "c",
        "out":        os.path.join(SCRIPT_DIR, "figure_2_panel_c.pdf"),
        "conditions": [
            (pc_50,  C50,  LW_COND, "50%"),
            (pc_25,  C25,  LW_COND, "25%"),
            (pc_0,   C0,   LW_COND, "0%"),
            (pc_all, CALL, LW_ALL,  "All"),
        ],
        "legend": False,
    },
]

for panel in PANELS:
    fig, ax = plt.subplots(figsize=(5, 5))

    handles = []
    for data, color, lw, label in panel["conditions"]:
        x, y = smooth_pdf(data)
        h, = ax.plot(x, y, color=color, linewidth=lw, label=label)
        handles.append(h)

    format_ax(ax, panel["label"])

    if panel["legend"]:
        leg = ax.legend(
            handles=handles,
            labels=[c[3] for c in panel["conditions"]],
            title=r"$\mathrm{\%RT}$",
            title_fontsize=14,
            fontsize=14,
            loc="upper left",
            framealpha=0.9,
        )

    fig.tight_layout()
    fig.savefig(panel["out"], dpi=200)
    print(f"Saved → {panel['out']}")
    plt.close(fig)
