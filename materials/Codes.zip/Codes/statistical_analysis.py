"""Statistical analysis for the individual pedestrian experiment (Figure 8 / hexagonal arena).

Tests reported in the manuscript:
  - One-sample Wilcoxon signed-rank test of mean individual polarization against 0
  - Bootstrap 95% CI for the median
  - Mann-Whitney U tests: handedness, footedness, eye dominance, sex, eye patch
  - Hodges-Lehmann estimator + bootstrap 95% CI for each pairwise comparison
"""

import numpy as np
import openpyxl
from scipy import stats

XLSX_PATH = "../SourceData.xlsx"

wb = openpyxl.load_workbook(XLSX_PATH, read_only=True, data_only=True)
ws = wb["Figure 8"]

records = []
for row_idx, row in enumerate(ws.iter_rows(values_only=True)):
    # Rows 0-2: section headers; row 3: column headers; data from row 4 onward
    if row_idx < 4:
        continue
    # Panel-e columns: 18=Id, 19=Hand, 20=Foot, 21=Eye, 22=Sex, 23=Patch, 24=Pol
    if row[18] is None:
        continue
    records.append({
        "Hand":  row[19],
        "Foot":  row[20],
        "Eye":   row[21],
        "Sex":   row[22],
        "Patch": str(row[23]),
        "Pol":   float(row[24]),
    })

wb.close()

print(f"Raw participant count: {len(records)}")

records = [r for r in records
           if r["Hand"] not in ("A", None)
           and r["Foot"] not in ("A", None)
           and r["Eye"]  not in ("A", None)]

print(f"After excluding ambidextrous: {len(records)}")

d2 = [r for r in records if r["Patch"] == "0"]
d3 = [r for r in records if r["Patch"] == "1"]
print(f"No-patch (d2): {len(d2)}    With-patch (d3): {len(d3)}")

def pol(subset):
    return np.array([r["Pol"] for r in subset], dtype=float)


def report_wilcoxon_one_sample(data, null_value=0, description=""):
    data = data[~np.isnan(data)]
    n = len(data)
    W, p = stats.wilcoxon(data - null_value, alternative="two-sided")
    mu    = n * (n + 1) / 4
    sigma = np.sqrt(n * (n + 1) * (2 * n + 1) / 24)
    z     = (W - mu) / sigma
    r     = z / np.sqrt(n)
    print(f"{description}: n={n}, W={W:.0f}, z={z:.2f}, P={p:.4e}, |r|={abs(r):.2f}")
    return z, p, r


def report_mannwhitney(data1, data2, label1, label2, description=""):
    data1 = data1[~np.isnan(data1)]
    data2 = data2[~np.isnan(data2)]
    n1, n2 = len(data1), len(data2)
    U, p = stats.mannwhitneyu(data1, data2, alternative="two-sided")
    mu_U    = n1 * n2 / 2
    sigma_U = np.sqrt(n1 * n2 * (n1 + n2 + 1) / 12)
    z       = (U - mu_U) / sigma_U
    r       = z / np.sqrt(n1 + n2)
    print(f"{description}: {label1} (n={n1}) vs {label2} (n={n2})  "
          f"U={U:.1f}, z={z:.2f}, P={p:.4e}, r={r:.2f}")
    return U, z, p, r


def bootstrap_median_ci(data, n_boot=5000, ci=95, seed=42):
    rng  = np.random.default_rng(seed)
    data = data[~np.isnan(data)]
    meds = [np.median(rng.choice(data, size=len(data), replace=True))
            for _ in range(n_boot)]
    lo = np.percentile(meds, (100 - ci) / 2)
    hi = np.percentile(meds, 100 - (100 - ci) / 2)
    return lo, hi


def hodges_lehmann(g1, g2):
    diffs = np.subtract.outer(g1, g2).ravel()
    return np.median(diffs)


def bootstrap_hl_ci(g1, g2, n_boot=5000, ci=95, seed=42):
    rng = np.random.default_rng(seed)
    g1, g2 = g1[~np.isnan(g1)], g2[~np.isnan(g2)]
    hl_vals = [hodges_lehmann(rng.choice(g1, size=len(g1), replace=True),
                              rng.choice(g2, size=len(g2), replace=True))
               for _ in range(n_boot)]
    lo = np.percentile(hl_vals, (100 - ci) / 2)
    hi = np.percentile(hl_vals, 100 - (100 - ci) / 2)
    return lo, hi


print("\n--- Overall (no-patch participants) ---")
pol_d2 = pol(d2)

report_wilcoxon_one_sample(pol_d2, null_value=0, description="Overall Wilcoxon")
lo, hi = bootstrap_median_ci(pol_d2)
print(f"Bootstrap 95% CI for median: [{lo:.2f}, {hi:.2f}]")

print("\n--- Handedness ---")
g_R = pol([r for r in d2 if r["Hand"] == "R"])
g_L = pol([r for r in d2 if r["Hand"] == "L"])
report_mannwhitney(g_R, g_L, "Right", "Left", "Handedness")
hl = hodges_lehmann(g_R, g_L)
hl_lo, hl_hi = bootstrap_hl_ci(g_R, g_L)
print(f"HL Right-Left: {hl:.2f}, 95% CI [{hl_lo:.2f}, {hl_hi:.2f}]")

print("\n--- Footedness ---")
g_R = pol([r for r in d2 if r["Foot"] == "R"])
g_L = pol([r for r in d2 if r["Foot"] == "L"])
report_mannwhitney(g_R, g_L, "Right", "Left", "Footedness")
hl = hodges_lehmann(g_R, g_L)
hl_lo, hl_hi = bootstrap_hl_ci(g_R, g_L)
print(f"HL Right-Left: {hl:.2f}, 95% CI [{hl_lo:.2f}, {hl_hi:.2f}]")

print("\n--- Eye dominance ---")
g_R = pol([r for r in d2 if r["Eye"] == "R"])
g_L = pol([r for r in d2 if r["Eye"] == "L"])
report_mannwhitney(g_R, g_L, "Right", "Left", "Eye dominance")
hl = hodges_lehmann(g_R, g_L)
hl_lo, hl_hi = bootstrap_hl_ci(g_R, g_L)
print(f"HL Right-Left: {hl:.2f}, 95% CI [{hl_lo:.2f}, {hl_hi:.2f}]")

print("\n--- Sex ---")
g_M = pol([r for r in d2 if r["Sex"] == "M"])
g_F = pol([r for r in d2 if r["Sex"] == "F"])
report_mannwhitney(g_M, g_F, "Male", "Female", "Sex")
hl = hodges_lehmann(g_M, g_F)
hl_lo, hl_hi = bootstrap_hl_ci(g_M, g_F)
print(f"HL Male-Female: {hl:.2f}, 95% CI [{hl_lo:.2f}, {hl_hi:.2f}]")

print("\n--- Eye patch ---")
pol_no_patch = pol(d2)
pol_patch    = pol(d3)
report_mannwhitney(pol_no_patch, pol_patch, "No patch", "Patch", "Eye patch")
hl = hodges_lehmann(pol_no_patch, pol_patch)
hl_lo, hl_hi = bootstrap_hl_ci(pol_no_patch, pol_patch)
print(f"HL No-patch minus Patch: {hl:.2f}, 95% CI [{hl_lo:.2f}, {hl_hi:.2f}]")
