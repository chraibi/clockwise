"""Figure 4 — PDF of collective polarization M for additional experiments.

Panels:
  a — Spain open schoolyard (Patio)
  b — Japan, N-pedestrian effect (N = 10, 15, 20, 25, 30, 35)
  c — Japan, %RT effect (100%(12), 50%(12), 50%(24))
  d — Kids (Guardería), four age groups
"""

import os
import numpy as np
import openpyxl
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from scipy.interpolate import interp1d
from scipy.ndimage import uniform_filter1d

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE  = os.path.join(SCRIPT_DIR, "..", "SourceData.xlsx")
OUT_FILE   = os.path.join(SCRIPT_DIR, "figure_4.pdf")

print("Loading data…")
wb   = openpyxl.load_workbook(DATA_FILE, read_only=True)
ws   = wb["Figure 4"]
rows = list(ws.iter_rows(values_only=True))
wb.close()
print("Data loaded.")

def col_values(col_idx, skip=4):
    return np.array([float(r[col_idx]) for r in rows[skip:] if r[col_idx] is not None])

# col 1 = Patio; cols 4–9 = Japan N-ped; cols 12–14 = Japan %RT; cols 17–20 = Kids ages
pa = col_values(1)
pb = [col_values(c) for c in range(4, 10)]
pc = [col_values(c) for c in range(12, 15)]
pd = [col_values(c) for c in range(17, 21)]

N_BINS  = 20
BIN_LIM = (-1.0, 1.0)

def smooth_pdf(data, floor_zero=False):
    counts, edges = np.histogram(data, bins=N_BINS, range=BIN_LIM, density=True)
    centers = edges[:-1] + (edges[1] - edges[0]) / 2
    f       = interp1d(centers, counts, kind="cubic", fill_value="extrapolate")
    x_fine  = np.linspace(centers[0], centers[-1], len(centers) * 2 - 1)
    y_fine  = uniform_filter1d(f(x_fine), size=5)
    if floor_zero:
        y_fine = np.maximum(y_fine, 0.0)
    return x_fine, y_fine

CM = ["#EA5D47", "#9E0142", "#3D5A80", "#56A110", "#FDBF6F", "#55AFAD"]

def format_ax(ax, xlabel=True):
    ax.axvline(0, color="black", linestyle="--", linewidth=3, zorder=2)
    ax.set_xlim(-1, 1)
    ax.set_ylim(-0.05, 3.5)
    if xlabel:
        ax.set_xlabel(r"$M$", fontsize=23)
    ax.set_ylabel("pdf", fontsize=23)
    ax.tick_params(which="both", direction="in", length=0.04 * 550,
                   width=1.5, labelsize=23)
    ax.xaxis.set_minor_locator(ticker.AutoMinorLocator(2))
    ax.yaxis.set_minor_locator(ticker.AutoMinorLocator(2))
    ax.tick_params(which="minor", length=0.04 * 550 * 0.6)
    for sp in ax.spines.values():
        sp.set_linewidth(1.5)
    ax.set_aspect(2 / 3.55)

fig, axes = plt.subplots(1, 4, figsize=(20, 5.5))
fig.subplots_adjust(left=0.07, right=0.98, top=0.95, bottom=0.14, wspace=0.40)

ax = axes[0]
x, y = smooth_pdf(pa, floor_zero=False)
ax.plot(x, y, color=CM[3], linewidth=4)
format_ax(ax)
ax.text(0.04, 0.97, "a", transform=ax.transAxes,
        fontsize=23, fontweight="bold", va="top")

ax = axes[1]
N_LABELS = ["10", "15", "20", "25", "30", "35"]
handles_b = []
for i, (data, label) in enumerate(zip(pb, N_LABELS)):
    x, y = smooth_pdf(data, floor_zero=False)
    h, = ax.plot(x, y, color=CM[i], linewidth=4, label=label)
    handles_b.append(h)
format_ax(ax)
leg_b = ax.legend(handles=handles_b, labels=N_LABELS,
                  title=r"$\mathrm{\# Ped}$", title_fontsize=15,
                  fontsize=15, loc="upper left", framealpha=0.9)
ax.text(0.04, 0.97, "b", transform=ax.transAxes,
        fontsize=23, fontweight="bold", va="top")

ax = axes[2]
C_LABELS = ["100% (12)", "50% (12)", "50% (24)"]
handles_c = []
for i, (data, label) in enumerate(zip(pc, C_LABELS)):
    x, y = smooth_pdf(data, floor_zero=True)
    h, = ax.plot(x, y, color=CM[i], linewidth=4, label=label)
    handles_c.append(h)
format_ax(ax)
leg_c = ax.legend(handles=handles_c, labels=C_LABELS,
                  title=r"$\mathrm{\% RT}$", title_fontsize=15,
                  fontsize=15, loc="upper left", framealpha=0.9)
ax.text(0.04, 0.97, "c", transform=ax.transAxes,
        fontsize=23, fontweight="bold", va="top")

ax = axes[3]
AGE_LABELS = ["5.03", "5.28", "5.59", "5.71"]
handles_d = []
for i, (data, label) in enumerate(zip(pd, AGE_LABELS)):
    x, y = smooth_pdf(data, floor_zero=True)
    h, = ax.plot(x, y, color=CM[i], linewidth=4, label=label)
    handles_d.append(h)
format_ax(ax)
leg_d = ax.legend(handles=handles_d, labels=AGE_LABELS,
                  title=r"$\overline{\mathrm{Age}}$", title_fontsize=15,
                  fontsize=15, loc="upper left", framealpha=0.9)
ax.text(0.04, 0.97, "d", transform=ax.transAxes,
        fontsize=23, fontweight="bold", va="top")

fig.savefig(OUT_FILE, dpi=200, bbox_inches="tight")
print(f"Saved → {OUT_FILE}")
plt.show()
