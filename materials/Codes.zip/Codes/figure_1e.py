"""Figure 1e — Time-averaged collective polarization (M̄) per experiment."""

import os
import numpy as np
import openpyxl
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE  = os.path.join(SCRIPT_DIR, "..", "SourceData.xlsx")
OUT_FILE   = os.path.join(SCRIPT_DIR, "figure_1e.pdf")

wb   = openpyxl.load_workbook(DATA_FILE, read_only=True)
ws   = wb["Figure 1e"]
rows = list(ws.iter_rows(values_only=True))
wb.close()

data = []
for row in rows[3:]:          # skip title, blank, header rows
    exp, n_rep, mean_pol, sem = row
    if exp is None:
        continue
    data.append({
        "exp":    str(exp),
        "n_rep":  int(n_rep),
        "mean":   float(mean_pol),
        "sem":    float(sem),
        "series": str(exp)[0],
    })

SERIES_COLOUR = {
    "A": "#EA5D47",
    "B": "#9E0142",
    "C": "#3D5A80",
    "D": "#56A110",
}

# x positions: A1-A11 → 1-11, B1 → 13, C1-C10 → 15-24, D1-D4 → 26-29
x_map = {}
for i, d in enumerate([d for d in data if d["series"] == "A"]):
    d["x"] = i + 1

x_map["B1"] = 13

for i, d in enumerate([d for d in data if d["series"] == "C"]):
    d["x"] = 15 + i

for i, d in enumerate([d for d in data if d["series"] == "D"]):
    d["x"] = 26 + i

for d in data:
    if d["series"] == "B":
        d["x"] = 13

# D-series (nursery) rescaled by 4/7 to fit the shared y-axis
D_SCALE = 4 / 7
for d in data:
    if d["series"] == "D":
        d["mean_plot"] = d["mean"] * D_SCALE
        d["sem_plot"]  = d["sem"]  * D_SCALE
    else:
        d["mean_plot"] = d["mean"]
        d["sem_plot"]  = d["sem"]

fig, ax = plt.subplots(figsize=(16, 4.5))

BG_REGIONS = [
    (-1,  12, "#EA5D47"),
    (12,  14, "#9E0142"),
    (14,  25, "#3D5A80"),
    (25,  30, "#56A110"),
]
for x0, x1, col in BG_REGIONS:
    ax.axvspan(x0, x1, ymin=0, ymax=1, color=col, alpha=0.2, linewidth=0, zorder=0)

for xsep in [12, 14, 25]:
    ax.axvline(xsep, color="0.25", linestyle=":", linewidth=2, zorder=2)

for d in data:
    col = SERIES_COLOUR[d["series"]]
    ax.errorbar(d["x"], d["mean_plot"], yerr=d["sem_plot"],
                fmt="none", ecolor=col, elinewidth=1.5,
                capsize=0, zorder=3)
    ax.scatter(d["x"], d["mean_plot"], s=200,
               color=col, edgecolors="black", linewidths=0.8,
               zorder=4)

ax.set_xlim(0, 30)
ax.set_ylim(-0.25, 0.72)

# Slight x-offset for A10/A11 to prevent label crowding
x_tick_pos    = [d["x"] for d in data]
x_tick_labels = [d["exp"] for d in data]
for i, d in enumerate(data):
    if d["exp"] == "A10":
        x_tick_pos[i] += 0.1
    if d["exp"] == "A11":
        x_tick_pos[i] += 0.3

ax.set_xticks(x_tick_pos)
ax.set_xticklabels(x_tick_labels, fontsize=14)

# Y-axis break: remapped tick labels (0.4 → 0.7, 0.6 → 0.9)
Y_TICK_POS    = [-0.2, 0.0, 0.2, 0.4, 0.6]
Y_TICK_LABELS = ["-0.2", "0", "0.2", "0.7", "0.9"]
ax.set_yticks(Y_TICK_POS)
ax.set_yticklabels(Y_TICK_LABELS, fontsize=18)

ax.set_ylabel(r"$\overline{M}$", fontsize=22, labelpad=8)

ax.tick_params(which="both", direction="in", length=6, width=1.5)
for sp in ax.spines.values():
    sp.set_linewidth(1.5)
ax.set_axisbelow(False)

ax.axhline(0, color="black", linewidth=1.5, linestyle="--", zorder=2)

# Axis break marks between y = 0.2 and y = 0.4, drawn in axes-normalised coords
ylim = ax.get_ylim()
y_break_lo_ax = (0.28 - ylim[0]) / (ylim[1] - ylim[0])
y_break_hi_ax = (0.32 - ylim[0]) / (ylim[1] - ylim[0])
dx_ax = 0.006
dy_ax = 0.022
for yc_ax in [y_break_lo_ax, y_break_hi_ax]:
    ax.plot([-dx_ax, dx_ax], [yc_ax - dy_ax, yc_ax + dy_ax],
            color="white", linewidth=3.0,
            transform=ax.transAxes, clip_on=False, zorder=5)
    ax.plot([-dx_ax, dx_ax], [yc_ax - dy_ax, yc_ax + dy_ax],
            color="black", linewidth=1.5,
            transform=ax.transAxes, clip_on=False, zorder=6)

from matplotlib.transforms import blended_transform_factory
trans = blended_transform_factory(ax.transData, ax.transAxes)
for d in data:
    ax.text(d["x"], -0.14, f"({d['n_rep']})",
            ha="center", va="top", fontsize=11,
            color="#555555", transform=trans)

fig.subplots_adjust(left=0.06, right=0.99, top=0.96, bottom=0.18)
fig.savefig(OUT_FILE, dpi=200, bbox_inches="tight")
print(f"Saved → {OUT_FILE}")
plt.show()
