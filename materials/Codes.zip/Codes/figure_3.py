"""Figure 3 — Spatial field maps: density, velocity, and polarization.

Layout: 3 rows × 4 columns (100 %RT | 50 %RT | 25 %RT | 0 %RT).
Data source: SourceData.xlsx, sheets "Figure 3a"–"Figure 3l".
"""

import os
import numpy as np
import openpyxl
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import Circle
from matplotlib.colors import Normalize


SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE  = os.path.join(SCRIPT_DIR, "..", "SourceData.xlsx")
OUT_FILE   = os.path.join(SCRIPT_DIR, "figure_3.pdf")

# Arena grid parameters (from FieldsFigure.m)
NX = NY       = 550
CIRCLE_XY     = (277.5, 277.5)   # arena centre in cell coordinates
CIRCLE_R      = 237.5             # arena radius (4.75 m × 50 cells/m)
TICK_POS      = [50, 275, 500]
TICK_LAB      = ['-5', '0', '5']
CONDITIONS    = ['100% RT', '50% RT', '25% RT', '0% RT']

CLIM_D  = (0,    0.8)
CLIM_V  = (1.0,  1.5)
CLIM_P  = (-0.3, 0.3)

CMAP_D  = 'inferno'
CMAP_V  = 'viridis'
CMAP_P  = plt.cm.coolwarm.reversed()   # flipud(coolwarm) in Matlab

# One arrow per 68-cell grid step, fixed length 60 cells
STEP     = NX // 8
LINE_LEN = 60


def read_matrix(ws, n=550):
    rows = []
    for i, row in enumerate(ws.iter_rows(values_only=True)):
        if i >= n:
            break
        rows.append([
            np.nan if (v is None or v == 'nan') else float(v)
            for v in row[:n]
        ])
    return np.array(rows, dtype=float)


def mask_flags(arr, threshold=10.0):
    """Replace flag values (Inf stored as 65535 in Excel) with NaN."""
    out = arr.copy()
    out[out > threshold] = np.nan
    return out


def format_ax(ax, left_col, bottom_row):
    ax.set_xlim(0, NX)
    ax.set_ylim(0, NY)
    ax.set_aspect('equal')
    ax.tick_params(direction='out', length=4, width=1.5, labelsize=13)
    for sp in ax.spines.values():
        sp.set_linewidth(1.5)
    ax.set_xticks(TICK_POS)
    ax.set_yticks(TICK_POS)
    ax.set_xticklabels(TICK_LAB if bottom_row else [], fontsize=13)
    ax.set_yticklabels(TICK_LAB if left_col  else [], fontsize=13)
    if left_col:
        ax.set_ylabel('Y (m)', fontsize=13)
    if bottom_row:
        ax.set_xlabel('X (m)', fontsize=13)


print("Loading data — may take ~1–2 min for large matrices…")
wb = openpyxl.load_workbook(DATA_FILE, read_only=True)

density = [read_matrix(wb[f'Figure 3{s}']) for s in 'abcd']

velocity = []
for L in 'efgh':
    vx = mask_flags(read_matrix(wb[f'Figure 3{L} VelX']))
    vy = mask_flags(read_matrix(wb[f'Figure 3{L} VelY']))
    vm = mask_flags(read_matrix(wb[f'Figure 3{L} ModVel']))
    velocity.append((vx, vy, vm))

polarization = [read_matrix(wb[f'Figure 3{s}']) for s in 'ijkl']
wb.close()
print("Data loaded.")

xs_idx = np.arange(0, NX, STEP)
ys_idx = np.arange(0, NY, STEP)
Xg, Yg = np.meshgrid(xs_idx + 0.5, ys_idx + 0.5)

fig = plt.figure(figsize=(14, 9.5))
gs  = gridspec.GridSpec(
    3, 5, figure=fig,
    width_ratios=[1, 1, 1, 1, 0.05],
    hspace=0.05, wspace=0.06,
    left=0.08, right=0.92, top=0.93, bottom=0.07,
)

axes_d = [fig.add_subplot(gs[0, c]) for c in range(4)]
axes_v = [fig.add_subplot(gs[1, c]) for c in range(4)]
axes_p = [fig.add_subplot(gs[2, c]) for c in range(4)]
cax_d  = fig.add_subplot(gs[0, 4])
cax_v  = fig.add_subplot(gs[1, 4])
cax_p  = fig.add_subplot(gs[2, 4])

for c, (ax, dat) in enumerate(zip(axes_d, density)):
    ax.pcolormesh(dat, cmap=CMAP_D,
                  vmin=CLIM_D[0], vmax=CLIM_D[1], rasterized=True)
    ax.add_patch(Circle(CIRCLE_XY, CIRCLE_R,
                        fill=False, edgecolor='white',
                        linestyle='--', linewidth=1.0))
    ax.set_title(CONDITIONS[c], fontsize=13)
    format_ax(ax, left_col=(c == 0), bottom_row=False)

cb_d = fig.colorbar(
    plt.cm.ScalarMappable(norm=Normalize(*CLIM_D), cmap=CMAP_D), cax=cax_d)
cb_d.set_label(r'$\langle\rho\rangle\;(\mathrm{m}^{-2})$', fontsize=12)
cb_d.ax.tick_params(labelsize=11, length=4)

norm_v = Normalize(*CLIM_V)
for c, (ax, (vx, vy, vm)) in enumerate(zip(axes_v, velocity)):
    u = vx[ys_idx[:, None], xs_idx[None, :]]
    v = vy[ys_idx[:, None], xs_idx[None, :]]
    m = vm[ys_idx[:, None], xs_idx[None, :]]

    mag   = np.sqrt(u**2 + v**2)
    valid = (mag > 0) & ~np.isnan(mag)
    un    = np.where(valid, u / mag * LINE_LEN, 0.0)
    vn    = np.where(valid, v / mag * LINE_LEN, 0.0)
    mc    = np.where(valid, m, np.nan)

    ax.quiver(
        Xg, Yg, un, vn, mc,
        cmap=CMAP_V, norm=norm_v,
        scale=1, scale_units='xy', angles='xy',
        units='xy', width=4,
        headwidth=4, headlength=5,
        pivot='tail',
    )
    ax.add_patch(Circle(CIRCLE_XY, CIRCLE_R,
                        fill=False, edgecolor='black',
                        linestyle='--', linewidth=1.0))
    format_ax(ax, left_col=(c == 0), bottom_row=False)

cb_v = fig.colorbar(
    plt.cm.ScalarMappable(norm=norm_v, cmap=CMAP_V), cax=cax_v)
cb_v.set_label(r'$\langle|\vec{v}|\rangle\;(\mathrm{m\,s}^{-1})$', fontsize=12)
cb_v.ax.tick_params(labelsize=11, length=4)

norm_p = Normalize(*CLIM_P)
for c, (ax, dat) in enumerate(zip(axes_p, polarization)):
    ax.pcolormesh(dat, cmap=CMAP_P,
                  vmin=CLIM_P[0], vmax=CLIM_P[1], rasterized=True)
    ax.add_patch(Circle(CIRCLE_XY, CIRCLE_R,
                        fill=False, edgecolor='black',
                        linestyle='--', linewidth=1.0))
    format_ax(ax, left_col=(c == 0), bottom_row=True)

cb_p = fig.colorbar(
    plt.cm.ScalarMappable(norm=norm_p, cmap=CMAP_P), cax=cax_p)
cb_p.set_label(r'$\overline{M}_r$', fontsize=12)
cb_p.set_ticks(np.arange(-0.3, 0.31, 0.1))
cb_p.ax.tick_params(labelsize=11, length=4)

fig.savefig(OUT_FILE, dpi=150, bbox_inches='tight')
print(f"Saved → {OUT_FILE}")
plt.show()
