"""Figure 7 — Distribution of individual time-averaged polarization (m̄_i)."""

import os
import numpy as np
import openpyxl
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE  = os.path.join(SCRIPT_DIR, "..", "SourceData.xlsx")

wb   = openpyxl.load_workbook(DATA_FILE, read_only=True)
ws   = wb["Figure 7"]
rows = list(ws.iter_rows(values_only=True))
wb.close()

# rows[3] is the first data row
def col_values(col_idx, skip=3):
    return np.array([float(r[col_idx]) for r in rows[skip:]
                     if r[col_idx] is not None])

# col 1 = Pza Toros, col 4 = Patio, col 7 = Japan, col 10 = Guarderia
pa = col_values(1)
pb = col_values(4)
pc = col_values(7)
pd = col_values(10)


def matlab_smooth(y, span):
    """Symmetric moving average matching Matlab's smooth().
    Effective half-window = (span-1)//2; shrinks symmetrically at boundaries."""
    half = (span - 1) // 2
    n    = len(y)
    out  = np.empty(n)
    for i in range(n):
        k      = min(half, i, n - 1 - i)
        out[i] = np.mean(y[i - k : i + k + 1])
    return out


def smooth_pdf(data, n_bins, bin_lim, n_interp, smooth_w=None):
    counts, edges = np.histogram(data, bins=n_bins, range=bin_lim, density=True)
    centers = edges[:-1] + (edges[1] - edges[0]) / 2
    f      = interp1d(centers, counts, kind="cubic", fill_value="extrapolate")
    x_fine = np.linspace(centers[0], centers[-1], n_interp)
    y_fine = f(x_fine)
    if smooth_w is not None:
        y_fine = matlab_smooth(y_fine, smooth_w)
    return x_fine, y_fine


PANELS = [
    dict(label="a", data=pa, colour="#e85c45",
         n_bins=50,  bin_lim=(-1.01, 1.01), n_interp=100, smooth=None, alpha=0.4),
    dict(label="b", data=pb, colour="#9c003f",
         n_bins=25,  bin_lim=(-1.05, 1.05), n_interp=50,  smooth=None, alpha=0.6),
    dict(label="c", data=pc, colour="#3a597f",
         n_bins=50,  bin_lim=(-1.05, 1.05), n_interp=100, smooth=None, alpha=0.6),
    dict(label="d", data=pd, colour="#56a110",
         n_bins=100, bin_lim=(-1.05, 1.05), n_interp=100, smooth=20,   alpha=0.6),
]

XTICKS   = [-1, -0.5, 0, 0.5, 1]
XLIM     = (-1.05, 1.05)
PDF_YLIM = (0, 2)
SC_YLIM  = (-2.5, 2.5)
FS       = 22
TL       = 5

RNG = np.random.default_rng(42)

for panel in PANELS:
    out_file = os.path.join(SCRIPT_DIR, f"figure_7_panel_{panel['label']}.pdf")
    col  = panel["colour"]
    data = panel["data"]

    fig = plt.figure(figsize=(4.5, 5.0))
    ax1 = fig.add_axes([0.18, 0.52, 0.78, 0.43])   # PDF (top)
    ax2 = fig.add_axes([0.18, 0.13, 0.78, 0.36])   # scatter (bottom)

    x_pdf, y_pdf = smooth_pdf(data,
                               panel["n_bins"], panel["bin_lim"],
                               panel["n_interp"], panel["smooth"])
    ax1.plot(x_pdf, y_pdf, color=col, linewidth=4)

    ax1.set_xlim(XLIM)
    ax1.set_ylim(PDF_YLIM)
    ax1.set_xticks(XTICKS)
    ax1.set_xticklabels([])
    ax1.set_ylabel("PDF", fontsize=FS)
    ax1.tick_params(which="both", direction="in",
                    length=TL, width=1.5, labelsize=FS)
    for sp in ax1.spines.values():
        sp.set_linewidth(1.5)
    ax1.text(0.04, 0.93, panel["label"], transform=ax1.transAxes,
             fontsize=FS, fontweight="bold", va="top")

    y_jitter = RNG.uniform(-2, 2, size=len(data))
    ax2.scatter(data, y_jitter, s=14, color=col,
                alpha=panel["alpha"], edgecolors="none", zorder=3)

    ax2.set_xlim(XLIM)
    ax2.set_ylim(SC_YLIM)
    ax2.set_xticks(XTICKS)
    ax2.set_yticks([])
    ax2.set_xlabel(r"$\overline{m_i}$", fontsize=FS)
    ax2.tick_params(which="both", direction="in",
                    length=TL, width=1.5, labelsize=FS)
    for sp in ax2.spines.values():
        sp.set_linewidth(1.5)

    fig.savefig(out_file, dpi=200, bbox_inches="tight")
    print(f"Saved → {out_file}  "
          f"(n={len(data)}, bins={panel['n_bins']}, "
          f"lim={panel['bin_lim']}, n_interp={panel['n_interp']}, "
          f"smooth={panel['smooth']})")
    plt.close(fig)
