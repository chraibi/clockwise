"""Figure 5, Panel b — Social norm questionnaire responses (proportions).

Panel a is a 3D rendering; only panel b is generated here.
Data source: SourceData.xlsx, sheet "Figure 5".
"""

import os
import openpyxl
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib.transforms import blended_transform_factory

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE  = os.path.join(SCRIPT_DIR, "..", "SourceData.xlsx")
OUT_FILE   = os.path.join(SCRIPT_DIR, "figure_5.pdf")

wb   = openpyxl.load_workbook(DATA_FILE, read_only=True)
ws   = wb["Figure 5"]
rows = list(ws.iter_rows(values_only=True))
wb.close()

# Keep only rows that have a Q1 value (col 0 not None) — excludes the Total row
counts_raw = [int(r[3]) for r in rows[4:] if r[0] is not None]
total = sum(counts_raw)   # 168

# Grouping: [CCW/CCW/CCW, CW/CW/CW, CW/CCW/CCW, CCW/CW/CW, OTHERS] / total
proportions = np.array([
    counts_raw[6],
    counts_raw[0],
    counts_raw[2],
    counts_raw[4],
    counts_raw[1] + counts_raw[3] + counts_raw[5] + counts_raw[7],
]) / total

COLOURS = ["#5E4FA2", "#55AFAD", "#FDBF6F", "#EA5D47", "#9E0142"]

LABELS_Q1 = ["CCW", "CW",  "CW",  "CCW", ""]
LABELS_Q2 = ["CCW", "CW",  "CCW", "CW",  "OTHERS"]
LABELS_Q3 = ["CCW", "CW",  "CCW", "CW",  ""]

fig, ax = plt.subplots(figsize=(6, 5.5))

x = np.arange(1, 6)
bars = ax.bar(x, proportions, color=COLOURS, width=0.6,
              edgecolor="black", linewidth=1.2, zorder=3)

ax.set_xlim(-0.2, 5.7)
ax.set_ylim(0, 0.42)
ax.set_ylabel("Proportion", fontsize=17)
ax.yaxis.set_major_locator(ticker.MultipleLocator(0.1))
ax.yaxis.set_minor_locator(ticker.MultipleLocator(0.05))
ax.tick_params(which="major", direction="in", length=6, width=1.5, labelsize=17)
ax.tick_params(which="minor", direction="in", length=3, width=1.0)
for sp in ax.spines.values():
    sp.set_linewidth(1.5)

ax.grid(axis="both", color="0.75", linewidth=0.8, zorder=0)
ax.set_axisbelow(True)

# Hide default x-ticks; replaced by three-row Q1/Q2/Q3 labels below
ax.set_xticks(x)
ax.set_xticklabels([""] * 5)
ax.tick_params(axis="x", length=0)

FONTSIZE_LBL = 13
ROW_Y   = [-0.11, -0.20, -0.29]
ROW_LBL = [LABELS_Q1, LABELS_Q2, LABELS_Q3]
ROW_TAG = ["Q1", "Q2", "Q3"]

trans = blended_transform_factory(ax.transData, ax.transAxes)

for row_y, labels in zip(ROW_Y, ROW_LBL):
    for xi, lbl in zip(x, labels):
        ax.text(xi, row_y, lbl,
                ha="center", va="top", fontsize=FONTSIZE_LBL,
                transform=trans)

TAG_X = 0.35
for row_y, tag in zip(ROW_Y, ROW_TAG):
    ax.text(TAG_X, row_y, rf"$\mathbf{{{tag}}}$",
            ha="right", va="top", fontsize=FONTSIZE_LBL,
            transform=trans)

ax.text(0.04, 0.97, "b", transform=ax.transAxes,
        fontsize=17, fontweight="bold", va="top")

fig.subplots_adjust(left=0.16, right=0.97, top=0.97, bottom=0.28)
fig.savefig(OUT_FILE, dpi=200, bbox_inches="tight")
print(f"Saved → {OUT_FILE}")
print(f"Proportions: {proportions.round(3)}  (total={total})")
plt.show()
