"""Figure 2 inset — Speed and M(t) time series for one example experiment."""

import os
import numpy as np
import openpyxl
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE  = os.path.join(SCRIPT_DIR, "..", "SourceData.xlsx")
OUT_FILE   = os.path.join(SCRIPT_DIR, "figure_2_inset.pdf")

wb   = openpyxl.load_workbook(DATA_FILE, read_only=True)
ws   = wb["Figure 2"]
rows = list(ws.iter_rows(values_only=True))
wb.close()

t   = np.array([float(r[17]) for r in rows[4:] if r[17] is not None])
spd = np.array([float(r[18]) for r in rows[4:] if r[18] is not None])
M   = np.array([float(r[19]) for r in rows[4:] if r[19] is not None])

# Excluded time windows (initial stage and periods of directed motion toward walls)
GREY_WINDOWS = [(0, 10), (40, 50), (80, 90)]

def grey_mask(t):
    mask = np.zeros(len(t), dtype=bool)
    for t0, t1 in GREY_WINDOWS:
        mask |= (t >= t0) & (t <= t1)
    return mask

grey = grey_mask(t)

def plot_seg(ax, t, y, grey_mask, color_free, lw_free=2.5, lw_grey=2.6):
    n = len(t)
    i = 0
    while i < n:
        j = i
        is_grey = grey_mask[i]
        while j < n and (grey_mask[j] == is_grey):
            j += 1
        end = min(j + 1, n)   # one extra point at boundary for continuity
        col = "0.70" if is_grey else color_free
        lw  = lw_grey  if is_grey else lw_free
        ax.plot(t[i:end], y[i:end], color=col, linewidth=lw, solid_capstyle="round")
        i = j

fig, (ax1, ax2) = plt.subplots(
    2, 1,
    figsize=(5.5, 5.0),
    gridspec_kw={"hspace": 0.12},
)

plot_seg(ax1, t, spd, grey, color_free="#4DB3D4")
ax1.set_ylim(0, 1.5)
ax1.set_xlim(0, 130)
ax1.set_ylabel("Speed (m/s)", fontsize=12, labelpad=6)
ax1.set_xticklabels([])
ax1.tick_params(which="both", direction="out", length=5, width=1.5, labelsize=12)
ax1.yaxis.set_minor_locator(ticker.AutoMinorLocator(2))
for sp in ax1.spines.values():
    sp.set_linewidth(1.5)

plot_seg(ax2, t, M, grey, color_free="#CC2222")
ax2.axhline(0, color="black", linewidth=2.0, linestyle="--")
ax2.set_ylim(-0.30, 0.60)
ax2.set_xlim(0, 130)
ax2.set_ylabel(r"$M$", fontsize=14, labelpad=6)
ax2.set_xlabel("Time (s)", fontsize=12, labelpad=4)
ax2.tick_params(which="both", direction="out", length=5, width=1.5, labelsize=12)
ax2.yaxis.set_minor_locator(ticker.AutoMinorLocator(2))
for sp in ax2.spines.values():
    sp.set_linewidth(1.5)

fig.subplots_adjust(left=0.20, right=0.97, top=0.97, bottom=0.12, hspace=0.12)
fig.savefig(OUT_FILE, dpi=200, bbox_inches="tight")
print(f"Saved → {OUT_FILE}")
plt.show()
