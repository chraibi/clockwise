"""Figure 8 — Rotational motion of individuals (hexagonal enclosure experiment).

Panels produced (panel a is a photograph):
  figure_8_panel_b_traj.pdf  — trajectories of two pedestrians, colored by m_i
  figure_8_panel_b_pdfs.pdf  — PDFs of instantaneous m_i
  figure_8_panel_c.pdf       — PDF of individual time-averaged m̄_i
  figure_8_panel_d.pdf       — synthetic collective polarization M̃
  figure_8_panel_e.pdf       — box plots of m̄_i grouped by individual features
"""

import numpy as np
import openpyxl
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from scipy.interpolate import interp1d
from scipy.stats import gaussian_kde

DATA_PATH  = '../SourceData.xlsx'
OUT_PREFIX = 'figure_8'

# ColorBrewer Paired-10 palette (panel e scatter colours)
PAIRED10 = [
    '#a6cee3', '#1f78b4', '#b2df8a', '#33a02c',
    '#fb9a99', '#e31a1c', '#fdbf6f', '#ff7f00',
    '#cab2d6', '#6a3d9a',
]

wb   = openpyxl.load_workbook(DATA_PATH, read_only=True)
ws   = wb['Figure 8']
rows = list(ws.iter_rows(values_only=True))
wb.close()

# Panel b — row 3 holds string headers; trajectory data starts at row 4
traj1 = np.array(
    [(r[0], r[1], r[2]) for r in rows[4:] if r[0] is not None], dtype=float
)
traj2 = np.array(
    [(r[3], r[4], r[5]) for r in rows[4:] if r[3] is not None], dtype=float
)

# Panel c — first m̄_i value is in row 3 (same row as the column header)
mbar_i = np.array([r[8] for r in rows[3:] if r[8] is not None], dtype=float)

GROUP_SIZES  = [10, 15, 20, 25, 30, 35]
GROUP_COLORS = ['#ea5d47', '#9e0142', '#3d5a80', '#56a110', '#fdbf6f', '#55afad']
group_data   = {
    gs: np.array([r[col] for r in rows[4:] if r[col] is not None], dtype=float)
    for gs, col in zip(GROUP_SIZES, [11, 12, 13, 14, 15, 16])
}

PANEL_E_SRC = (
    '/mnt/Disk2TB/Experimento_Rotation/Hexagono/Statistical-Test/'
    'IndData-WithPolarization-NoAmb.xlsx'
)
_wb_e   = openpyxl.load_workbook(PANEL_E_SRC, read_only=True)
_rows_e = list(_wb_e.active.iter_rows(values_only=True))
_wb_e.close()
panel_e = [
    {
        'hand':  r[1],
        'foot':  r[2],
        'eye':   r[3],
        'sex':   r[4],
        'patch': str(r[5]),
        'pol':   float(r[7]),
    }
    for r in _rows_e[1:]
]


def px_to_in(px):
    return px / 96.0


fig_b_w   = px_to_in(265)
fig_b_h   = px_to_in(508)
cmap_traj = plt.cm.coolwarm_r   # red at CW (m_i = -1), blue at CCW (m_i = +1)
norm_traj = Normalize(vmin=-1, vmax=1)

fig = plt.figure(figsize=(fig_b_w, fig_b_h))
fig.patch.set_facecolor('white')

ax1 = fig.add_axes([0.1434, 0.4952, 0.5962, 0.3798])
ax2 = fig.add_axes([0.1434, 0.0938, 0.5962, 0.3798])

for ax, traj in zip([ax1, ax2], [traj1, traj2]):
    ax.scatter(traj[:, 0], traj[:, 1], s=35, c=traj[:, 2],
               cmap=cmap_traj, norm=norm_traj, linewidths=0)
    ax.set_aspect('equal')
    ax.set_xlim(-6, 6)
    ax.set_ylim(-6, 6)
    ax.set_xticks([-5, 5])
    ax.set_yticks([-5, 5])
    ax.tick_params(direction='in', length=6, width=2, labelsize=22)
    for spine in ax.spines.values():
        spine.set_linewidth(2)

ax1.set_ylabel('Y (m)', fontsize=22)
ax2.set_xlabel('X (m)', fontsize=22)
ax2.set_ylabel('Y (m)', fontsize=22)

cax = fig.add_axes([0.1358, 0.905, 0.5962, 0.04])
cb  = fig.colorbar(
    plt.cm.ScalarMappable(norm=norm_traj, cmap=cmap_traj),
    cax=cax, orientation='horizontal'
)
cb.set_ticks([-1, 1])
cb.ax.xaxis.set_ticks_position('top')
cb.ax.xaxis.set_label_position('top')
cb.ax.tick_params(labelsize=16, direction='out', length=4)

fig.savefig(f'{OUT_PREFIX}_panel_b_traj.pdf', format='pdf', bbox_inches='tight')
plt.close(fig)
print(f'Saved {OUT_PREFIX}_panel_b_traj.pdf')

fig = plt.figure(figsize=(fig_b_w, fig_b_h))
fig.patch.set_facecolor('white')

ax1 = fig.add_axes([0.1434, 0.4952, 0.5962, 0.3798])
ax2 = fig.add_axes([0.1434, 0.0938, 0.5962, 0.3798])

for ax, traj in zip([ax1, ax2], [traj1, traj2]):
    N, edges    = np.histogram(traj[:, 2], bins=100, density=True, range=(-1.05, 1.05))
    bin_centers = edges[:-1] + np.diff(edges) / 2
    ax.plot(bin_centers, N, color='#7AAF78', linewidth=3)
    ax.set_box_aspect(1)
    ax.set_xlim(-1.15, 1.15)
    ax.set_ylim(0, 8.0)
    ax.set_xticks([-1, 1])
    ax.tick_params(direction='in', length=6, width=1.5, labelsize=22)
    for spine in ax.spines.values():
        spine.set_linewidth(1.5)
    ax.yaxis.set_label_position('right')
    ax.yaxis.tick_right()
    ax.set_ylabel('PDF', fontsize=13)

ax2.set_xlabel(r'$m_i$', fontsize=16)

fig.savefig(f'{OUT_PREFIX}_panel_b_pdfs.pdf', format='pdf', bbox_inches='tight')
plt.close(fig)
print(f'Saved {OUT_PREFIX}_panel_b_pdfs.pdf')

# Panel c — 45-bin histogram → cubic spline, 80 points
fig_cd_w = px_to_in(453)
fig_cd_h = px_to_in(512)
xtick_c  = np.arange(-1, 1.01, 0.5)

fig, ax = plt.subplots(figsize=(fig_cd_w, fig_cd_h))
fig.patch.set_facecolor('white')

N, edges    = np.histogram(mbar_i, bins=45, density=True, range=(-1.05, 1.05))
bin_centers = edges[:-1] + np.diff(edges) / 2
interp_pts  = np.linspace(bin_centers.min(), bin_centers.max(), 80)
interp_Y    = interp1d(bin_centers, N, kind='cubic')(interp_pts)

ax.plot(interp_pts, interp_Y, color='#d4a32c', linewidth=4)
ax.axvline(0, linestyle='--', linewidth=3, color='black')
ax.set_box_aspect(1)
ax.set_xlim(-1.1, 1.1)
ax.set_ylim(0, 2)
ax.set_xticks(xtick_c)
ax.tick_params(direction='in', length=5, width=1.5, labelsize=24)
for spine in ax.spines.values():
    spine.set_linewidth(1.5)
ax.set_ylabel('PDF', fontsize=24)
ax.set_xlabel(r'$\overline{m_i}$', fontsize=24)

fig.tight_layout()
fig.savefig(f'{OUT_PREFIX}_panel_c.pdf', format='pdf', bbox_inches='tight')
plt.close(fig)
print(f'Saved {OUT_PREFIX}_panel_c.pdf')

# Panel d — kernel density estimate of synthetic collective polarization
fig, ax = plt.subplots(figsize=(fig_cd_w, fig_cd_h))
fig.patch.set_facecolor('white')

xi_range     = np.linspace(-1.1, 1.1, 500)
plot_handles = []

for gi, gsize in enumerate(GROUP_SIZES):
    kde = gaussian_kde(group_data[gsize])
    h,  = ax.plot(xi_range, kde(xi_range), linewidth=4, color=GROUP_COLORS[gi])
    plot_handles.append(h)

ax.axvline(0, linestyle='--', linewidth=3, color='black')
ax.set_box_aspect(1)
ax.set_xlim(-1.1, 1.1)
ax.set_ylim(-0.05, 3.5)
ax.set_xticks(xtick_c)
ax.tick_params(direction='in', length=5, width=1.5, labelsize=24)
for spine in ax.spines.values():
    spine.set_linewidth(1.5)
ax.set_ylabel('PDF', fontsize=24)
ax.set_xlabel(r'$\tilde{M}$', fontsize=24)
ax.legend(plot_handles, [str(gs) for gs in GROUP_SIZES],
          loc='upper left', fontsize=15, title='# Ped', title_fontsize=15)

fig.tight_layout()
fig.savefig(f'{OUT_PREFIX}_panel_d.pdf', format='pdf', bbox_inches='tight')
plt.close(fig)
print(f'Saved {OUT_PREFIX}_panel_d.pdf')

# Panel e — box plots of m̄_i grouped by individual features.
# Hand, Foot, Eye, Sex: non-patched subjects only (Patch == '0').
# Patch variable: all participants.
# Categories with fewer than 5 members are excluded.
# Beeswarm: data binned in 0.1-wide bins; dots spread symmetrically within each bin.
# Invalid categories still advance j, keeping x-positions consistent across variables.
fig_e_w   = px_to_in(1616)
fig_e_h   = px_to_in(505)
VAR_KEYS  = ['hand', 'foot', 'eye', 'sex', 'patch']
BIN_EDGES = np.arange(-1.05, 1.056, 0.1)
Y_BINS    = BIN_EDGES[:-1] + 0.05
DELTA     = 0.055

patch_arr         = np.array([r['patch'] for r in panel_e])
all_box_positions = []
scatter_info      = []
sample_sizes      = []
cont_cat          = 0
cont_color        = 0

for vi, var_key in enumerate(VAR_KEYS):
    mask        = (patch_arr == '0') if vi < 4 else np.ones(len(panel_e), dtype=bool)
    current_var = np.array([r[var_key] for r in panel_e])[mask]
    current_pol = np.array([r['pol']   for r in panel_e], dtype=float)[mask]

    seen = []
    for v in current_var:
        if v not in seen:
            seen.append(v)

    valid_count = 0
    for j, cat in enumerate(seen, start=1):
        data_cat = current_pol[current_var == cat]
        if len(data_cat) < 5:
            continue

        pos = j + cont_cat
        all_box_positions.append((pos, data_cat))
        sample_sizes.append((pos, len(data_cat)))

        bin_idx = np.clip(np.digitize(data_cat, BIN_EDGES) - 1, 0, len(Y_BINS) - 1)
        x_adj, y_adj = [], []
        for bi, yv in enumerate(Y_BINS):
            pts   = data_cat[bin_idx == bi]
            count = len(pts)
            if count == 0:
                continue
            x_adj.extend(
                (pos + DELTA * (np.arange(1, count + 1) - np.ceil(count / 2))).tolist()
            )
            y_adj.extend([yv] * count)

        scatter_info.append((np.array(x_adj), np.array(y_adj), PAIRED10[cont_color]))
        valid_count += 1
        cont_color  += 1

    cont_cat += valid_count

fig, ax = plt.subplots(figsize=(fig_e_w, fig_e_h))
fig.patch.set_facecolor('white')

gray = (0.5, 0.5, 0.5)
ax.boxplot(
    [d for _, d in all_box_positions],
    positions    = [p for p, _ in all_box_positions],
    widths       = 0.5,
    patch_artist = False,
    showfliers   = False,
    medianprops  = dict(color='black', linewidth=1.5),
    whiskerprops = dict(color=gray,    linewidth=1.5),
    capprops     = dict(color=gray,    linewidth=1.5),
    boxprops     = dict(color=gray,    linewidth=1.5),
)

for x_pos, y_pos, color in scatter_info:
    ax.scatter(x_pos, y_pos, s=14, color=color, linewidths=0, zorder=3)

ax.axhline(0, color='black', linewidth=1.5, linestyle='--', zorder=2)

for xp, n in sample_sizes:
    ax.text(xp, 1.12, f'({n})', ha='center', va='bottom', fontsize=20)

ax.set_xlim(0, 11)
ax.set_ylim(-1.1, 1.35)
ax.set_xticks([])
ax.set_ylabel(r'$\overline{m}_i$', fontsize=30)
ax.tick_params(labelsize=25, width=1.5)
for spine in ax.spines.values():
    spine.set_linewidth(1.5)

fig.tight_layout()
fig.savefig(f'{OUT_PREFIX}_panel_e.pdf', format='pdf', bbox_inches='tight')
plt.close(fig)
print(f'Saved {OUT_PREFIX}_panel_e.pdf')
