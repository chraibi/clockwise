"""Figure 6 — Individual pedestrian trajectories coloured by instantaneous polarisation."""

import os
import numpy as np
import openpyxl
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec
from matplotlib.colors import Normalize

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE  = os.path.join(SCRIPT_DIR, "..", "SourceData.xlsx")
OUT_FILE   = os.path.join(SCRIPT_DIR, "figure_6.pdf")

wb   = openpyxl.load_workbook(DATA_FILE, read_only=True)
ws   = wb["Figure 6"]
rows = list(ws.iter_rows(values_only=True))
wb.close()

# Sheet layout: row 4+ = data; col groups (frame, x, y, pol) per panel
COL_GROUPS = [(0, 1, 2, 3), (5, 6, 7, 8), (10, 11, 12, 13), (15, 16, 17, 18)]

panels = []
for fc, xc, yc, pc in COL_GROUPS:
    data = [(r[xc], r[yc], r[pc]) for r in rows[4:] if r[fc] is not None]
    xpos = np.array([float(d[0]) for d in data])
    ypos = np.array([float(d[1]) for d in data])
    pol  = np.array([float(d[2]) for d in data])
    panels.append((xpos, ypos, pol))

R_CIRCLE  = 4.75
CMAP      = "coolwarm_r"      # flipud(coolwarm) in Matlab
GREEN_HEX = "#7AAF78"
NORM      = Normalize(vmin=-1, vmax=1)

fig = plt.figure(figsize=(5.1, 10.4), facecolor="white")

gs = GridSpec(
    4, 2,
    figure=fig,
    left=0.10, right=0.93,
    top=0.97, bottom=0.05,
    wspace=0.55, hspace=0.32,
)

scatter_axes = [fig.add_subplot(gs[i, 0]) for i in range(4)]
pdf_axes     = [fig.add_subplot(gs[i, 1]) for i in range(4)]

sc_plot = None
for i, ax in enumerate(scatter_axes):
    xpos, ypos, pol = panels[i]

    sc_plot = ax.scatter(
        xpos, ypos,
        s=35, c=pol, cmap=CMAP, norm=NORM,
        zorder=2,
    )

    circle = mpatches.Circle(
        (0, 0), R_CIRCLE,
        fill=False, linestyle="--",
        edgecolor="black", linewidth=1,
        zorder=3,
    )
    ax.add_patch(circle)

    ax.set_aspect("equal", adjustable="box")
    ax.set_xlim(-5.25, 5.25)
    ax.set_ylim(-5.25, 5.25)
    ax.set_xticks([-4.75, 4.75])
    ax.set_xticklabels(["-4", "4"])
    ax.set_yticks([-4.75, 4.75])
    ax.set_yticklabels(["-4", "4"])
    ax.tick_params(
        which="both", direction="out", length=6, width=1.5, labelsize=12,
        top=True, bottom=True, left=True, right=True,
        labeltop=False, labelbottom=True, labelleft=True, labelright=False,
    )
    for sp in ax.spines.values():
        sp.set_linewidth(1.5)
    ax.set_xlabel("X (m)", fontsize=11, labelpad=2)
    ax.set_ylabel("Y (m)", fontsize=11, labelpad=2)

for i, ax in enumerate(pdf_axes):
    _, _, pol = panels[i]

    # Raw bin-centre histogram (no interpolation or smoothing)
    counts, bin_edges = np.histogram(pol, bins=100, range=(-1.05, 1.05), density=True)
    bin_centers = bin_edges[:-1] + (bin_edges[1] - bin_edges[0]) / 2

    ax.plot(bin_centers, counts, color=GREEN_HEX, linewidth=3)

    ax.set_box_aspect(1)
    ax.set_xlim(-1.15, 1.15)
    ax.set_ylim(0, 8.0)
    ax.set_xticks([-1, 1])
    ax.set_xticklabels(["-1", "1"])

    ax.yaxis.set_label_position("right")
    ax.tick_params(
        which="both", direction="in", length=5, width=1.5, labelsize=12,
        top=True, bottom=True, left=True, right=True,
        labeltop=False, labelbottom=True, labelleft=False, labelright=True,
    )
    for sp in ax.spines.values():
        sp.set_linewidth(1.5)
    ax.set_ylabel("PDF", fontsize=13)
    # labelpad≈0 matches xlab.Position(2)*0.04 in Matlab
    ax.set_xlabel(r"$m_i$", fontsize=16, labelpad=0)

fig.canvas.draw()

pos_sc_top = scatter_axes[0].get_position()
pos_sc_bot = scatter_axes[-1].get_position()

cb_x  = pos_sc_top.x1 + 0.02
cb_y  = pos_sc_bot.y0
cb_w  = 0.026
cb_h  = pos_sc_top.y1 - cb_y

cbar_ax = fig.add_axes([cb_x, cb_y, cb_w, cb_h])
cb = fig.colorbar(sc_plot, cax=cbar_ax)
cb.mappable.set_clim(-1, 1)
cb.set_ticks(np.arange(-0.8, 0.81, 0.2))
cb.ax.tick_params(labelsize=12, width=1.0)
cb.ax.set_title(r'$m_i(t)$', fontsize=16, pad=8)

fig.savefig(OUT_FILE, dpi=200, bbox_inches="tight")
print(f"Saved → {OUT_FILE}")
plt.close(fig)
